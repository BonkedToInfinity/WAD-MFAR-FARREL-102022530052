<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelanggan</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
<div class="container">
    <header class="form-header"><h2>Edit Pelanggan</h2></header>
    <form method="POST" action="{{ route('pelanggan.update', $pelanggan) }}" class="laundry-form">
        @method('PUT')
        @include('biodata_form')
    </form>
</div>
</body>
</html>