<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
<div class="container">
    <header class="form-header">
        <h2>Modul Data Pelanggan</h2>
        <p>Kelola biodata, nomor telepon, dan catatan penanganan khusus pakaian.</p>
    </header>

    <div class="top-bar">
        <span>{{ auth()->user()->name }} ({{ auth()->user()->role }})</span>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="btn btn-secondary">Logout</button>
        </form>
    </div>

    @if (session('success'))
        <div class="alert-success">{{ session('success') }}</div>
    @endif

    <a href="{{ route('pelanggan.create') }}" class="btn btn-primary link-btn" style="width:100%; margin-bottom:20px;">+ Tambah Pelanggan</a>

    @forelse ($pelanggan as $p)
        <div class="customer-card">
            <div>
                <p><span>Nama:</span> {{ $p->nama }}</p>
                <p><span>No. Telp/WA:</span> {{ $p->nomortelpon }}</p>
                <p><span>Alamat:</span> {{ $p->alamat }}</p>
                <p><span>Catatan:</span> {{ $p->catatan }}</p>
            </div>
            <div class="card-actions">
                <a href="{{ route('pelanggan.edit', $p) }}" class="btn-card btn-edit">Edit</a>

                @if (auth()->user()->role === 'admin')
                    <form method="POST" action="{{ route('pelanggan.destroy', $p) }}"
                          onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn-card btn-delete" style="width:100%">Hapus</button>
                    </form>
                @endif
            </div>
        </div>
    @empty
        <p style="color:#666; font-size:14px;">Belum ada data pelanggan yang tersimpan.</p>
    @endforelse
</div>
</body>
</html>