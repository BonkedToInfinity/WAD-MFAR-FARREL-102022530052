@csrf
<div class="form-group">
    <label for="nama">Nama Lengkap</label>
    <input type="text" id="nama" name="nama" value="{{ old('nama', $pelanggan->nama ?? '') }}" required>
    @error('nama') <div class="alert-error">{{ $message }}</div> @enderror
</div>

<div class="form-group">
    <label for="nomortelpon">Nomor Telpon / WhatsApp</label>
    <input type="tel" id="nomortelpon" name="nomortelpon" value="{{ old('nomortelpon', $pelanggan->nomortelpon ?? '') }}" placeholder="Contoh: 081234567890" required>
    @error('nomortelpon') <div class="alert-error">Nomor telepon harus 8-20 digit angka.</div> @enderror
</div>

<div class="form-group">
    <label for="alamat">Alamat Pelanggan</label>
    <textarea id="alamat" name="alamat" rows="3">{{ old('alamat', $pelanggan->alamat ?? '') }}</textarea>
</div>

<div class="form-group">
    <label for="catatan">Catatan Penanganan Khusus Pakaian</label>
    <textarea id="catatan" name="catatan" rows="4" placeholder="Contoh: Baju putih jangan dicampur.">{{ old('catatan', $pelanggan->catatan ?? '') }}</textarea>
</div>

<div class="form-actions">
    <button type="submit" class="btn btn-primary">Simpan</button>
    <a href="{{ route('pelanggan.index') }}" class="btn btn-secondary link-btn">Batal</a>
</div>