<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
<div class="container">
    <header class="form-header"><h2>Tambah Pelanggan</h2></header>
    <form method="POST" action="{{ route('pelanggan.store') }}" class="laundry-form">
        @include('biodata_form')
    </form>
</div>
</body>
</html>