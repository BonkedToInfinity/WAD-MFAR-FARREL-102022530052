<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <p>Email: <input type="email" name="email" value="{{ old('email') }}" required></p>
        <p>Password: <input type="password" name="password" required></p>
        @error('email') <p style="color:red">{{ $message }}</p> @enderror
        <button type="submit">Masuk</button>
    </form>
</body>
</html>