<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\biodataController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('pelanggan.index'));

Route::get('/login', [AuthController::class, 'showLogin'])->name('login')->middleware('guest');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

Route::middleware('auth')->group(function () {
    // admin & kasir: lihat, tambah, edit
    Route::middleware('role:admin,kasir')->group(function () {
        Route::resource('pelanggan', biodataController::class)->except(['destroy', 'show']);
    });

    // hanya admin: hapus
    Route::delete('/pelanggan/{pelanggan}', [biodataController::class, 'destroy'])
        ->middleware('role:admin')
        ->name('pelanggan.destroy');
});