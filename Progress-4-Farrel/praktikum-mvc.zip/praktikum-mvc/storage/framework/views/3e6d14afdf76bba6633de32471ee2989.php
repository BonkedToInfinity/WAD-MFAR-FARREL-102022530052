<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="nama">Nama Lengkap</label>
    <input type="text" id="nama" name="nama" value="<?php echo e(old('nama', $pelanggan->nama ?? '')); ?>" required>
    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="nomortelpon">Nomor Telpon / WhatsApp</label>
    <input type="tel" id="nomortelpon" name="nomortelpon" value="<?php echo e(old('nomortelpon', $pelanggan->nomortelpon ?? '')); ?>" placeholder="Contoh: 081234567890" required>
    <?php $__errorArgs = ['nomortelpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error">Nomor telepon harus 8-20 digit angka.</div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="alamat">Alamat Pelanggan</label>
    <textarea id="alamat" name="alamat" rows="3"><?php echo e(old('alamat', $pelanggan->alamat ?? '')); ?></textarea>
</div>

<div class="form-group">
    <label for="catatan">Catatan Penanganan Khusus Pakaian</label>
    <textarea id="catatan" name="catatan" rows="4" placeholder="Contoh: Baju putih jangan dicampur."><?php echo e(old('catatan', $pelanggan->catatan ?? '')); ?></textarea>
</div>

<div class="form-actions">
    <button type="submit" class="btn btn-primary">Simpan</button>
    <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-secondary link-btn">Batal</a>
</div><?php /**PATH C:\PROJECT_WAD\praktikum-mvc\resources\views/biodata_form.blade.php ENDPATH**/ ?>