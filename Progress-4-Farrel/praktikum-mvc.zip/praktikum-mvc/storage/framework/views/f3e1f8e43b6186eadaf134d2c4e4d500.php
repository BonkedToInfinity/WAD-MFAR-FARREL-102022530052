<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<div class="container">
    <header class="form-header"><h2>Tambah Pelanggan</h2></header>
    <form method="POST" action="<?php echo e(route('pelanggan.store')); ?>" class="laundry-form">
        <?php echo $__env->make('biodata_form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>
</body>
</html><?php /**PATH C:\PROJECT_WAD\praktikum-mvc\resources\views/biodata_create.blade.php ENDPATH**/ ?>