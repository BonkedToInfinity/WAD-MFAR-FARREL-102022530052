<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<div class="container">
    <header class="form-header">
        <h2>Modul Data Pelanggan</h2>
        <p>Kelola biodata, nomor telepon, dan catatan penanganan khusus pakaian.</p>
    </header>

    <div class="top-bar">
        <span><?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->role); ?>)</span>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-secondary">Logout</button>
        </form>
    </div>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-primary link-btn" style="width:100%; margin-bottom:20px;">+ Tambah Pelanggan</a>

    <?php $__empty_1 = true; $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="customer-card">
            <div>
                <p><span>Nama:</span> <?php echo e($p->nama); ?></p>
                <p><span>No. Telp/WA:</span> <?php echo e($p->nomortelpon); ?></p>
                <p><span>Alamat:</span> <?php echo e($p->alamat); ?></p>
                <p><span>Catatan:</span> <?php echo e($p->catatan); ?></p>
            </div>
            <div class="card-actions">
                <a href="<?php echo e(route('pelanggan.edit', $p)); ?>" class="btn-card btn-edit">Edit</a>

                <?php if(auth()->user()->role === 'admin'): ?>
                    <form method="POST" action="<?php echo e(route('pelanggan.destroy', $p)); ?>"
                          onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-card btn-delete" style="width:100%">Hapus</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p style="color:#666; font-size:14px;">Belum ada data pelanggan yang tersimpan.</p>
    <?php endif; ?>
</div>
</body>
</html><?php /**PATH C:\PROJECT_WAD\praktikum-mvc\resources\views/biodata_view.blade.php ENDPATH**/ ?>