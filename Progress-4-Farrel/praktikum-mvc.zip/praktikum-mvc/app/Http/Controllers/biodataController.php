<?php

namespace App\Http\Controllers;

use App\Models\pelanggan_biodata;
use Illuminate\Http\Request;

class biodataController extends Controller
{
    private function rules(): array
    {
        return [
            'nama'        => ['required', 'string', 'max:255'],
            'nomortelpon' => ['required', 'regex:/^[0-9+]{8,20}$/'],
            'alamat'      => ['nullable', 'string'],
            'catatan'     => ['nullable', 'string'],
        ];
    }

    public function index()
    {
        $pelanggan = pelanggan_biodata::latest()->get();
        return view('biodata_view', compact('pelanggan'));
    }

    public function create()
    {
        return view('biodata_create');
    }

    public function store(Request $request)
    {
        pelanggan_biodata::create($request->validate($this->rules()));
        return redirect()->route('pelanggan.index')->with('success', 'Data pelanggan berhasil disimpan.');
    }

    public function edit(pelanggan_biodata $pelanggan)
    {
        return view('biodata_edit', compact('pelanggan'));
    }

    public function update(Request $request, pelanggan_biodata $pelanggan)
    {
        $pelanggan->update($request->validate($this->rules()));
        return redirect()->route('pelanggan.index')->with('success', 'Data pelanggan berhasil diubah.');
    }

    public function destroy(pelanggan_biodata $pelanggan)
    {
        $pelanggan->delete();
        return redirect()->route('pelanggan.index')->with('success', 'Data pelanggan berhasil dihapus.');
    }
}