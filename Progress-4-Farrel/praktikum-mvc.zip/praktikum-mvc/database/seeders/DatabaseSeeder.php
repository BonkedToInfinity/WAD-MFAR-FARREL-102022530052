<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        User::create(['name' => 'Admin', 'email' => 'admin@laundry.test', 'password' => 'password', 'role' => 'admin']);
        User::create(['name' => 'Kasir', 'email' => 'kasir@laundry.test', 'password' => 'password', 'role' => 'kasir']);
        User::create(['name' => 'Tamu',  'email' => 'tamu@laundry.test',  'password' => 'password', 'role' => 'tamu']);
    }
}